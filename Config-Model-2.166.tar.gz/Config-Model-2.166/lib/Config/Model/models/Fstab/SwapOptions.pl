#
# This file is part of Config-Model
#
# This software is Copyright (c) 2005-2022 by Dominique Dumont.
#
# This is free software, licensed under:
#
#   The GNU Lesser General Public License, Version 2.1, February 1999
#
use strict;
use warnings;
use v5.20;
use utf8;

return [
  {
    'author' => [
      'Dominique Dumont'
    ],
    'class_description' => 'Swap options',
    'copyright' => [
      '2010,2011 Dominique Dumont'
    ],
    'element' => [
      'sw',
      {
        'type' => 'leaf',
        'value_type' => 'boolean'
      }
    ],
    'license' => 'LGPL2',
    'name' => 'Fstab::SwapOptions'
  }
]
;
